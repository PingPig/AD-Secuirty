# Smbtouch-Scanner


Author: 3gstudent

License: BSD 3-Clause

---
Automatically scan the inner network.

Use Smbtouch.exe to detect whether the target is vulnerable.

**List of vulnerabilities：**

- ETERNALBLUE
- ETERNALCHAMPION
- ETERNALROMANCE
- ETERNALSYNERGY


Protocol: SMB

Scan port:445

**Note:**

   You can also use protocl NBT and port 139,just change the Smbtouch-1.1.1.xml

You can get Smbtouch.exe from this:

https://github.com/x0rz/EQGRP_Lost_in_Translation/blob/master/windows/touches/Smbtouch-1.1.1.exe

or

https://github.com/fuzzbunch/fuzzbunch/blob/master/touches/Smbtouch-1.1.1.exe

More details:

https://3gstudent.github.io/3gstudent.github.io/%E5%86%85%E7%BD%91%E5%AE%89%E5%85%A8-%E5%88%A9%E7%94%A8NSA-Smbtouch%E6%89%B9%E9%87%8F%E6%A3%80%E6%B5%8B%E5%86%85%E7%BD%91/

---

Maybe need to use multithread to improve efficiency.
